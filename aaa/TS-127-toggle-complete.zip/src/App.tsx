import React from "react";

import "./App.css";
import TodosWrapper from "./Components/TodosWrapper";

function App() {
  return <TodosWrapper />;
}

export default App;
